import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Line automatically modified by acpoa-builder
# Do not modify it manually unless you know what you are doing
files = []

setuptools.setup(
    name="sample_plugin",
    version="1.0.0",
    author="Leikt",
    author_email="leikt.solreihin@gmail.com",
    description="A simple test plugin",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="____url____",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.9",
    package_data={"": files}
)
