def add(*values):
    return sum(values)