from acpoa import PluginBase


class Plugin(PluginBase):
    def register_hooks(self):
        return []

    def on_run(self, *argv):
        print("Plugin2 is runnning")