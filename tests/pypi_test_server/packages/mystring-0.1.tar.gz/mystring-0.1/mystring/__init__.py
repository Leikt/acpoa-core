def show(*values):
    return ' '.join(values)